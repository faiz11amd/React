import React , {Component} from 'react';
import axios from 'axios';

class EmployeeStore extends Component{
    constructor(props){
        super(props);
        this.state = {
            employees : [],
            newEmployeeForm : {
                first_name : '',
                last_name : '',
                email : '',
                gender : '',
                ip_address : ''
            },
            editEmployeeForm : {
                first_name : '',
                last_name : '',
                email : '',
                gender : '',
                ip_address : ''
            }
        };
    }

    // life Cycle Method
    componentDidMount() {
        // Get all Employees from the server
        this.getAllEmployees();
    }

    getAllEmployees(){
        axios.get('/api/employees/')
            .then((response) => {
                this.setState({
                    employees : response.data
                });
                console.log(this.state.employees);
            })
            .catch(function (error) {
                // handle error
                console.log(error);
            })
            .finally(function () {
                // always executed
            });
    }

    // Change New Employee Form
    changeNewEmployeeForm = (e) => {
        // get the state info
        let newEmployeeForm = this.state.newEmployeeForm;

        // update the form data
        newEmployeeForm[e.target.name] = e.target.value;

        // Update form data to state
        this.setState({
            newEmployeeForm : newEmployeeForm
        });
    };

    // editEmployeeForm
    editEmployeeForm = (emp_id) => {
        // find the selected Employee from the state
        let editEmployeeForm = this.state.employees.find(employee => employee._id === emp_id);
        // Update form data to state
        this.setState({
            editEmployeeForm : editEmployeeForm
        });
    };

    // Change Edit Employee Form
    changeEditEmployeeForm = (e) => {
        // get the state info
        let editEmployeeForm = this.state.editEmployeeForm;

        // update the form data
        editEmployeeForm[e.target.name] = e.target.value;

        // Update form data to state
        this.setState({
            editEmployeeForm : editEmployeeForm
        });
    };

    // addEmployee
    addEmployee = () => {
        axios.post('/api/employees/', this.state.newEmployeeForm)
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    };

    // updateEmployee
    updateEmployee = () => {
        axios.put(`/api/employees/${this.state.editEmployeeForm.id}`, this.state.editEmployeeForm)
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    };

    // deleteEmployee
    deleteEmployee = (emp_id) => {
        axios.delete(`/api/employees/${emp_id}`)
            .then((response) => {
                this.getAllEmployees();
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    };

    render() {
        let employeeList = this.state.employees.map((employee) => (
            <tr key={employee._id}>
                <td>{employee.id}</td>
                <td>{employee.first_name}</td>
                <td>{employee.last_name}</td>
                <td>{employee.email}</td>
                <td>{employee.gender}</td>
                <td>{employee.ip_address}</td>
                <td>
                    <button className='btn btn-primary btn-sm mt-0' data-toggle='modal' data-target='#edit-emp-modal' onClick={this.editEmployeeForm.bind(this,employee._id)}>Edit</button>
                    <button className='btn btn-danger btn-sm mt-0' onClick={this.deleteEmployee.bind(this,employee.id)}>Delete</button>
                </td>
            </tr>
        ));
        return(
            <div>
                <div className="container-fluid mt-5">
                    <div className="row">
                        <div className="col">
                            <div className="card">
                                <div className="card-header bg-primary text-white">
                                    <h2> <i className='fa fa-users-cog'/> Employee Portal</h2>
                                </div>
                                <div className="card-body bg-light">
                                    <button className='btn btn-primary' data-toggle='modal' data-target='#new-emp-modal'>
                                       <i className='fa fa-user-circle'/> New Employee</button>
                                    <h3 className='float-right'>Total Records Found : {this.state.employees.length}</h3>

                                    { /*  Employee Table   */}
                                    <table className='table table-hover text-center mt-3'>
                                        <thead className='bg-dark text-white'>
                                            <tr>
                                                <th>EMP ID</th>
                                                <th>FIRST NAME</th>
                                                <th>LAST NAME</th>
                                                <th>EMAIL</th>
                                                <th>GENDER</th>
                                                <th>IP ADDRESS</th>
                                                <th>ACTIONS</th>
                                            </tr>
                                        </thead>
                                        <tbody className='bg-white t_body'>
                                            {employeeList}
                                        </tbody>
                                    </table>

                                    {/* New Employee Modal */}
                                    <div className="modal animated flipInY" id='new-emp-modal'>
                                        <div className="modal-dialog">
                                            <div className="modal-content">
                                                <div className="modal-header bg-primary text-white">
                                                    <h3>ADD New Employee</h3>
                                                    <button className='close' data-dismiss='modal'>
                                                        <i className='fa fa-times-circle'/>
                                                    </button>
                                                </div>
                                                <div className="modal-body bg-light">
                                                    <form>
                                                        <div className="form-group">
                                                            <input
                                                                type='text'
                                                                name='first_name'
                                                                className='form-control'
                                                                placeholder='First name'
                                                                value={this.state.newEmployeeForm.first_name}
                                                                onChange={this.changeNewEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <div className="form-group">
                                                            <input
                                                                type='text'
                                                                name='last_name'
                                                                className='form-control'
                                                                placeholder='Last name'
                                                                value={this.state.newEmployeeForm.last_name}
                                                                onChange={this.changeNewEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <div className="form-group">
                                                            <input
                                                                type='email'
                                                                name='email'
                                                                className='form-control'
                                                                placeholder='Email'
                                                                value={this.state.newEmployeeForm.email}
                                                                onChange={this.changeNewEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <div className="form-group">
                                                            <select
                                                                className='form-control'
                                                                name='gender'
                                                                value={this.state.newEmployeeForm.gender}
                                                                onChange={this.changeNewEmployeeForm}
                                                                required>
                                                                <option value="">Select Gender</option>
                                                                <option value="Male">Male</option>
                                                                <option value="Female">Female</option>
                                                            </select>
                                                        </div>
                                                        <div className="form-group">
                                                            <input
                                                                type='text'
                                                                name='ip_address'
                                                                className='form-control'
                                                                placeholder='IP Address'
                                                                value={this.state.newEmployeeForm.ip_address}
                                                                onChange={this.changeNewEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <button className='btn btn-primary' onClick={this.addEmployee}>Add Employee</button>
                                                        <button className='btn btn-dark' data-dismiss='modal'>Close</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Edit Employee Modal */}
                                    <div className="modal animated flipInX" id='edit-emp-modal'>
                                        <div className="modal-dialog">
                                            <div className="modal-content">
                                                <div className="modal-header bg-primary text-white">
                                                    <h3>Edit Employee</h3>
                                                    <button className='close' data-dismiss='modal'>
                                                        <i className='fa fa-times-circle'/>
                                                    </button>
                                                </div>
                                                <div className="modal-body bg-light">
                                                    <form>
                                                        <div className="form-group">
                                                            <input
                                                                type='text'
                                                                name='first_name'
                                                                className='form-control'
                                                                placeholder='First name'
                                                                value={this.state.editEmployeeForm.first_name}
                                                                onChange={this.changeEditEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <div className="form-group">
                                                            <input
                                                                type='text'
                                                                name='last_name'
                                                                className='form-control'
                                                                placeholder='Last name'
                                                                value={this.state.editEmployeeForm.last_name}
                                                                onChange={this.changeEditEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <div className="form-group">
                                                            <input
                                                                type='email'
                                                                name='email'
                                                                className='form-control'
                                                                placeholder='Email'
                                                                value={this.state.editEmployeeForm.email}
                                                                onChange={this.changeEditEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <div className="form-group">
                                                            <select
                                                                className='form-control'
                                                                name='gender'
                                                                value={this.state.editEmployeeForm.gender}
                                                                onChange={this.changeEditEmployeeForm}
                                                                required>
                                                                <option value="">Select Gender</option>
                                                                <option value="Male">Male</option>
                                                                <option value="Female">Female</option>
                                                            </select>
                                                        </div>
                                                        <div className="form-group">
                                                            <input
                                                                type='text'
                                                                name='ip_address'
                                                                className='form-control'
                                                                placeholder='IP Address'
                                                                value={this.state.editEmployeeForm.ip_address}
                                                                onChange={this.changeEditEmployeeForm}
                                                                required/>
                                                        </div>
                                                        <button className='btn btn-primary' onClick={this.updateEmployee}>Update Employee</button>
                                                        <button className='btn btn-dark' data-dismiss='modal'>Close</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default EmployeeStore;