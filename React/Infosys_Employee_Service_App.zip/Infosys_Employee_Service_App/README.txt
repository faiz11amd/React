Database Setup (MongoDB)
------------------------
use infosys_services
db.createCollection('employees');

Server (EXPRESS JS) startup (new command prompt)
------------------------------------------------
cd server
npm install
npm start

Client (REACT JS) startup (new command prompt)
----------------------------------------------
cd client
npm install
npm start