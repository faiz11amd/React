import React from "react";
import "./App.css";
import ChangeRangeSelect from "./components/ChangeRangeSelect";
import ChangeSelectBox from "./components/ChangeSelectBox";
import ChangePassword from "./components/ChangePassword";
import ChangeUserName from "./components/ChangeUserName";
import FirstEvent from "./components/FirstEvent";
import Greet from "./components/Greet";
import Welcome from "./components/Welcome";

function App() {
  return (
    <div>
      <div className="container mt-4">
        <div className="row">
          <div className="col-md-8">
            <div className="card">
              <div className="card-body bg-primary text-white">
                <ChangeRangeSelect />
                <ChangeSelectBox />
                <ChangePassword />
                <FirstEvent />
                <Greet />
                <Welcome />
              </div>{" "}
            </div>{" "}
          </div>{" "}
        </div>{" "}
      </div>{" "}
    </div>
  );
}

export default App;
