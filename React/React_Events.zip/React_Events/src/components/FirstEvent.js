import React , {Component} from 'react';

class FirstEvent extends Component{
    constructor(props){
        super(props);
        this.state = {
            message : 'Hello Welcome to React JS'
        };
    }

    // click Handler
    buttonHandler = () => {
        // change the state
        console.log(this);
        this.setState({
            message : 'Good Bye'
        });
    };

    render() {
        return(
            <div>
                <h1>{this.state.message}</h1>
                <button className='btn btn-primary' onClick={this.buttonHandler}>Click Me</button>
            </div>
        );
    }
}

export default FirstEvent;