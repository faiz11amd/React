import React , {Component} from 'react';

class Greet extends Component{
    /*constructor(props){
        super(props);
    }*/

    // click Handler
    buttonHandler = () => {
        console.log('Button is Clicked');
    };

    render() {
        return(
            <div>
                <button className='btn btn-primary' onClick={this.buttonHandler}>Click Me</button>
            </div>
        );
    }
}

export default Greet;