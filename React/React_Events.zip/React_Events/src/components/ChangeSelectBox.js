import React , {Component} from 'react';

class ChangeSelectBox extends Component{
    constructor(props){
        super(props);
        this.state = {
            selectedOption : ''
        };
    }

    // selectAnOption
    selectAnOption = (e) => {
        this.setState({
            selectedOption : e.target.value
        });
    };

    render() {
        return(
            <div>
               <form>
                   <div className="row">
                       <div className="col">
                           <div className="form-group">
                               <select
                                   className='form-control'
                                   onChange={this.selectAnOption}
                                    >
                                   <option value="">Select a Technology</option>
                                   <option value="HTML">HTML</option>
                                   <option value="CSS">CSS</option>
                                   <option value="JavaScript">JavaScript</option>
                                   <option value="JQuery">JQuery</option>
                                   <option value="Bootstrap">Bootstrap</option>
                               </select>
                           </div>
                       </div>
                       <div className="col">
                           <h3>{this.state.selectedOption}</h3>
                       </div>
                   </div>
               </form>
            </div>
        );
    }
}

export default ChangeSelectBox;