import React , {Component} from 'react';

class ChangePassword extends Component{
    constructor(props){
        super(props);
        this.state = {
            attr: 'password'
        };
    }

    changeThePassword = () => {
        this.setState({
            attr : (this.state.attr === 'password') ? 'text' : 'password'
        });
    };

    render() {
        return(
            <div>
               <form className='form-inline'>
                   <div className="form-group mr-3">
                       <input type={this.state.attr} className='form-control'/>
                   </div>
                   <div className='form-group'>
                       <input
                           type='checkbox'
                           className='form-check-input'
                           onChange={this.changeThePassword}/> Show Password
                   </div>
               </form>
            </div>
        );
    }
}

export default ChangePassword;