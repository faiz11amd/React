import React , {Component} from 'react';

class ChangeRangeSelect extends Component{
    constructor(props){
        super(props);
        this.state = {
            selectedValue : ''
        };
    }

    // changeRange
    changeRange = (e) => {
        this.setState({
            selectedValue : e.target.value
        });
    };

    render() {
        return(
            <div>
                <form className='form-inline'>
                    <div className="row">
                        <div className="col">
                            <div className="form-group mr-3">
                                <input
                                    type='range'
                                    className='custom-range'
                                    style={{width : '250px'}}
                                    onChange={this.changeRange}
                                    min = '5000'
                                    max= '50000'/>
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <h5 className='display-4'>&#8377; {new Intl.NumberFormat('en-IN', { maximumSignificantDigits: 3 }).format(this.state.selectedValue)}</h5>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}

export default ChangeRangeSelect;