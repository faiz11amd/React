import React from 'react';

let Welcome = () => {

    // click Handler
    let buttonHandler = () => {
        console.log('Button is Clicked');
    };

    return(
        <div>
            <button className='btn btn-primary' onClick={buttonHandler}>Click Me</button>
        </div>
    );
};

export default Welcome;