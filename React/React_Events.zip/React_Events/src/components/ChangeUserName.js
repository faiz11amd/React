import React , {Component} from 'react';

class ChangeUserName extends Component{
    constructor(props){
        super(props);
        this.state = {
            username : '',
            password : ''
        };
    }

    // changeInput
    changeInput = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        });
    };

    // form Submit
    submitForm = () => {
        alert(`USER NAME :${this.state.username}
               PASSWORD : ${this.state.password}`);
    };

    render() {
        return(
            <div>
                <form onSubmit={this.submitForm} method='post'>
                    <div className="form-group">
                        <input
                            type='text'
                            value={this.state.username}
                            name = 'username'
                            placeholder='User Name'
                            className='form-control'
                            onChange={this.changeInput}/>
                    </div>
                    <div className="form-group">
                        <input
                            type='password'
                            value={this.state.password}
                            name = 'password'
                            placeholder='Password'
                            className='form-control'
                            onChange={this.changeInput}/>
                    </div>
                    <button className='btn btn-secondary'>Submit</button>
                </form>
            </div>
        );
    }
}

export default ChangeUserName;