import "./Arrow.css";
import React from "react";

function template() {
  return (
    <div className="arrow" style={{top:this.state.t+'px',left:this.state.l+'px'}}>
    </div>
  );
};

export default template;
