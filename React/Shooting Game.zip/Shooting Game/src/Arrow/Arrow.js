import React    from "react";
import template from "./Arrow.jsx";

class Arrow extends React.Component {
  constructor(){
    super();

    this.state={
        t:0,
        l:0
    }
    window.addEventListener('keyup',(e)=>{
        debugger;
        if(e.keyCode == 40){
          if(this.state.t != 400){
           this.setState({
             t:this.state.t+5
           })
          }
        }

        if(e.keyCode == 38){
          if(this.state.t != 0){
          this.setState({
            t:this.state.t-5
          })
        }
        }
        if(e.keyCode == 13){
          if(this.props.baloonInfo == ''){
            alert('plesae select target baloon');
            return;
          }
         const {offsetTop,offsetLeft,offsetHeight} =this.props.baloonInfo;
         if(this.state.t > offsetTop && this.state.t <(offsetTop+offsetHeight)){
              var moveLeft= offsetLeft-50;
              var interVal=setInterval(()=>{
                    this.setState({
                      l:this.state.l+1
                    })
                    if(this.state.l == moveLeft){
                      clearInterval(interVal);
                      this.props.baloonInfo.style.display='none';
                      this.setState({
                        l:0,
                        t:0
                      })

                      this.props.fnClearBalInfo();

                    }
              },20)
         }else{
          var moveLeft= 350;
          var interVal=setInterval(()=>{
                this.setState({
                  l:this.state.l+1
                })
                if(this.state.l == moveLeft){
                  clearInterval(interVal);
                  this.setState({
                    l:0,
                    t:0
                  })
                }
          },20)
         }
        }
    })
  }
  render() {
    return template.call(this);
  }
}

export default Arrow;
