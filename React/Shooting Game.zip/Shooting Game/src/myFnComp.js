import React from 'react';

const myFn=(data)=>{
    console.log('my function ')
     return <div>My funcation compoet: {data.n}</div>
}

export default React.memo(myFn);