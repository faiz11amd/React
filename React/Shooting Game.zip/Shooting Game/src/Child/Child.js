import React    from "react";
import template from "./Child.jsx";

class Child extends React.Component {
  constructor(){
    super();
    setTimeout(()=>{
      try{
        let a;
        console.log(a.length);
      }catch(e){
        console.log(e);
      }
        
    },20000)
  }
  componentWillReceiveProps(){
    console.log('child: received new prop');
  }
  render() {
    return template.call(this);
  }
}

export default Child;
