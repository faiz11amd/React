import React    from "react";
import template from "./Service.jsx";
import $ from 'jquery';
import axios from 'axios';
class Service extends React.Component {
  constructor(){
    super();
    this.state={
      players:['sachin','dhoni','uv','khhli','Dravid'],
      alpha:['A','B','C'],
      nums:[1,2,3,4],
      data:[]
    }
  }
  render() {
    return template.call(this);
  }

  fnGetData(){
    debugger;
    //java Script
    // let httpObj= new XMLHttpRequest();
    // httpObj.open('get','https://jsonplaceholder.typicode.com/posts',true);
    // httpObj.send();
    // httpObj.onload=()=>{
    //   debugger;
    //   let res=httpObj.responseText;
    //   res=JSON.parse(res);
    //   this.setState({
    //     'data':res
    //   })
    // }
    // httpObj.onerror=()=>{
    //   debugger;
    // }

    //jQuery--1
    // $.get('https://jsonplaceholder.typicode.com/posts')
    // .then(
    //   (res)=>{
    //     debugger;
    //     this.setState({
    //       'data':res
    //     })
    //   },
    //   (res)=>{
    //     this.setState({
    //       'data':[]
    //     })
    //   }
    // )

    //jQuery -2

    // $.ajax({
    //   'url':'https://jsonplaceholder.typicode.com/posts',
    //   'method':'get'
    // })
    // .then((res)=>{
    //   debugger;
    //   this.setState({
    //     'data':res
    //   })
    // })
    // .catch(()=>{
    //   this.setState({
    //     'data':[]
    //   })
    // })

     //axios

    axios.get('https://jsonplaceholder.typicode.com/posts')
    .then(
      (res)=>{
        debugger;
        this.setState({
          'data':res.data
        })
      },
      (res)=>{
        this.setState({
          'data':[]
        })
      }
    )

  }
}

export default Service;
