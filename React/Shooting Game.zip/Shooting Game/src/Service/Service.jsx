import "./Service.css";
import React from "react";
import Selectcomp from '../selectcomp/selectcomp';
import ListComp from '../ListComp/ListComp'
function template() {
  return (
    <div className="service">
      <h1>Service</h1>
         <ListComp data={this.state.players} />
         <ListComp data={this.state.alpha} />

         <Selectcomp d={this.state.players} />
         <Selectcomp d={this.state.alpha} />
         <Selectcomp d={this.state.nums} />
      <select>
        {
          this.state.players.map((v, i) => {
            return <option key={'selKey' + i} >{v}</option>
          })
        }
      </select>

      <ol>
        {
          this.state.players.map((v, i) => {
            return <li key={'listKey' + i}>{v}</li>
          })
        }
      </ol>
      <table border='1px'>
      <tbody>
        <tr>
          <th>S.No</th>
          <th>Name</th>
        </tr>
        
        {
          this.state.players.map((v,i)=>{
              return  <tr key={'trKey'+i}>
                 <td>{i+1}</td>
                 <td>{v}</td>
               </tr>
          })
        }
        </tbody>
      </table>

      <div>
        <input type='button' value="get data" onClick={this.fnGetData.bind(this)} />
      </div>

      <div>
       {
         this.state.data.length !=0 && 
      
           <table border='1px'>
             <tbody>
                  <tr>
                    <th>ID</th>
                    <th>Body</th>
                    <th>Title</th>
                  </tr>

                  {
                    this.state.data.map((o,i)=>{
                          return <tr key={'postsTr'+i}>
                                 <td>{o.id}</td>
                                 <td>{o.body}</td>
                                 <td>{o.title}</td>
                          </tr>
                    })
                  }
             </tbody>
           </table>
       }
      </div>
    </div>
  );
};

export default template;
