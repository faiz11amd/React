import React    from "react";
import template from "./Home.jsx";

class Home extends React.Component {
  constructor(){
    super();
    console.log('constructoer executed');
    this.state={
      'num':0,
      'name':'sachin',
      'pd':[
        {
          'n':'sachin',
          'r':20000
        },
        {
          'n':'dhoni',
          'r':13000
        }
      ],
      'pk':['n','r'],
      'ph':['Player Name','His Runs'],
      'sd':[
        {
          'name':'s1',
          'rno':1,
          'marks':200
        },
        {
          'name':'s2',
          'rno':2,
          'marks':500
        },
        {
          'name':'s3',
          'rno':3,
          'marks':400
        }
      ],
      'sk':['name','rno','marks'],
      'sh':['studnet Name','Rno', 'marks']
    }

    setTimeout(()=>{
         this.setState({
           name:'dhoini'
         })
    },5000)

    setTimeout(()=>{
      this.setState({
        name:'kohli'
      })
 },10000)
  }
  render() {
    console.log('render');
    return template.call(this);
  }

  componentWillMount(){
    console.log('will mount');
  }

  componentDidMount(){
    console.log('did mount');
  }


  componentWillUpdate(){
    console.log('will update')
  }

  componentDidUpdate(){
    console.log('did update');
  }

  componentWillUnmount(){
    console.log('will unmound');
  }

  componentDidCatch(){
    alert('error came');
  }

  shouldComponentUpdate(prop,state){
    debugger;
     console.log('shoujd update');
    // if(state.name == 'dhoni'){
    //   return false;
    // }
    // return true;

    return true;
    
  }
  fnInc5(){
     for(var i=1;i<=5;i++){
      this.setState((prevState)=>{
         return {
           'num':prevState.num+1
         }
      })
     }
     console.log(this.state.num);
  }

  fnInc(){
     this.setState({
       'num':this.state.num+1
     },this.f)
     console.log('before update'+this.state.num);
  }

  f(){
    console.log('after'+this.state.num);
  }


}

export default Home;
