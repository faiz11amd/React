import "./Home.css";
import React from "react";
import Child from '../Child/index'
import TableCom from '../TableCom/index'
function template() {
  return (
    <div className="home">
      <h1>{this.state.name}</h1>
      <Child n={this.state.name} />

      <TableCom  h={this.state.ph} d={this.state.pd} k={this.state.pk} />
      <TableCom  h={this.state.sh} d={this.state.sd} k={this.state.sk}/>
      <div>
        <input type='button' value='inc' onClick={this.fnInc5.bind(this)} />
      </div>
      <h1>{this.state.num}</h1>
    </div>
  );
};

export default template;
