import "./TicTak.css";
import React from "react";
import Box from '../Box/index';
function template() {
  return (
    <div className="tic-tak">
      <div>
        <Box prev={this.state.prev} i="1" fnChageData={this.fnChageData} /><Box  prev={this.state.prev} i='2' fnChageData={this.fnChageData} /><Box  prev={this.state.prev} i='3' fnChageData={this.fnChageData} />
      </div>
      <div>
        <Box  prev={this.state.prev} i="4" fnChageData={this.fnChageData} /><Box  prev={this.state.prev} i='5' fnChageData={this.fnChageData} /><Box  prev={this.state.prev} i='6' fnChageData={this.fnChageData} />
      </div>
      <div>
        <Box  prev={this.state.prev} i="7" fnChageData={this.fnChageData} /><Box  prev={this.state.prev} i='8' fnChageData={this.fnChageData} /><Box  prev={this.state.prev} i='9' fnChageData={this.fnChageData} />
      </div>
    </div>
  );
};

export default template;
