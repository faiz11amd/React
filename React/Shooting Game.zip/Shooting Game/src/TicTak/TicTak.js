import React    from "react";
import template from "./TicTak.jsx";

class TicTak extends React.Component {
  constructor(){
    super();
    this.state={
      'prev':'y'
    }
    this.fnChageData=this.fnChageData.bind(this);
  }
  render() {
    return template.call(this);
  }

  fnChageData(data){
     debugger;
     this.setState({
       'prev':data
     })
  }
}

export default TicTak;
