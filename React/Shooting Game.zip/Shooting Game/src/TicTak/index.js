import TicTak from "./TicTak";
export default TicTak;
