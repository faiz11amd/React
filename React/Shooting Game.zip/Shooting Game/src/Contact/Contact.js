import React    from "react";
import template from "./Contact.jsx";

class Contact extends React.Component {
  constructor(){
    super();
    this.state={
       n:0
    }
    window.setInterval(()=>{
       this.setState({
         n:this.state.n+1
       })
    },1000);
  }
  render() {
    console.log('contact render');
    return template.call(this);
  }
}

export default Contact;
