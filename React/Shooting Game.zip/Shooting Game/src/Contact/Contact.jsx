import "./Contact.css";
import React from "react";
import Mypure from '../mypure/index';
import MyFn from '../myFnComp';
function template() {
  return (
    <div className="contact">
      <h1>Contact</h1>
      <Mypure n={this.state.n} />
      <MyFn n={this.state.n}/>
    </div>
  );
};

export default template;
