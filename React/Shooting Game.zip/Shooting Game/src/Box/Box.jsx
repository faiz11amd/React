import "./Box.css";
import React from "react";

function template() {
  return (
       <div className="box" contentEditable id={this.props.i} onKeyUp={this.fnKeyUp.bind(this)}>
          
       </div>
  );
};

export default template;
