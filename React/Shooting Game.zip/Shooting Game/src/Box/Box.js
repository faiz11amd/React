import React    from "react";
import template from "./Box.jsx";

class Box extends React.Component {
  
  render() {
    return template.call(this);
  }

  fnKeyUp(e){
    debugger;
    var targetEle=e.target;
    var id=targetEle.id;
    var _val=targetEle.innerText.toLowerCase();
    if(_val == ''){
      if(this.props.prev == 'x'){
        this.props.fnChageData('y')
      }else{
        this.props.fnChageData('x');
      }
      return;
    }
    if(!(_val == 'x' || _val == 'y')){
        alert('wrong entry');
        document.getElementById(id).innerText='';
        return;
    }


    if(this.props.prev == _val){
        alert('wrong entry');
        document.getElementById(id).innerText='';
        return;
    }

    this.props.fnChageData(_val);

    var groups=[[1,2,3],[4,5,6,],[7,8,9],[1,4,7],[2,5,8],[3,6,9],[1,5,9],[3,5,7]];

    var selGroups=groups.filter((v,i)=>{
         return  v.includes(Number(id));
    })

    for(var i=0;i<selGroups.length;i++){
        var group= selGroups[i];
        var _val1=document.getElementById(group[0]).innerText;
        var _val2=document.getElementById(group[1]).innerText;
        var _val3=document.getElementById(group[2]).innerText;
        
        if(_val1 == _val && _val2 == _val && _val3== _val){
          alert('you won');
          window.location.reload()
          break;
        }
    }

    debugger;

  }
}

export default Box;
