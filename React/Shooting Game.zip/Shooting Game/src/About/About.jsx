import "./About.css";
import React from "react";
import A from '../A/index';
import {ctx} from '../context'
import TicTak from '../TicTak/index';
import Board from '../Board/index';
function template() {
  return (
    <div className="about">
      <h1>About</h1>
     <ctx.Provider value={this.state.name}>
      <A />
     </ctx.Provider>

     <TicTak />
     <Board />
    </div>
  );
};

export default template;
