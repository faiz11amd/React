import Menu1 from "./Menu1";
export default Menu1;
