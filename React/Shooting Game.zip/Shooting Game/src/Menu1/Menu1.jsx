import "./Menu1.css";
import React from "react";
import {BrowserRouter,Route,Link} from 'react-router-dom';
import Home from '../Home/index';
import About from '../About/index';
import Contact from '../Contact/index';
import Service from '../Service/index'
function template() {
  return (
    <div className="menu-1">
       <BrowserRouter>
          <div>
               <ul className="list-menu">
                 <li><Link to="/home">Home</Link></li>
                 <li><Link to="/about">About</Link></li>
                 <li><Link to="/contact">Contact</Link></li>
                 <li><Link to="/service">Service</Link></li>
               </ul>
               <Route path='/' exact component={Home} />
          <Route  path="/home" component={Home} />
          <Route  path="/about" component={About} />
          <Route  path="/contact" component={Contact} />
          <Route  path="/service" component={Service} />

          </div>
       </BrowserRouter>
    </div>
  );
};

export default template;
