import React    from "react";
import template from "./Menu1.jsx";

class Menu1 extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Menu1;
