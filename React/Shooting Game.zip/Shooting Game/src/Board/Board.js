import React    from "react";
import template from "./Board.jsx";

class Board extends React.Component {
  constructor(){
    super();
    this.state={
      baloonInfo:''
    }
    this.fnGetBalInfo=this.fnGetBalInfo.bind(this);
    this.fnClearBalInfo=this.fnClearBalInfo.bind(this);
  }
  render() {
    return template.call(this);
  }

  fnClearBalInfo(){
      this.setState({
        baloonInfo:''
      })
  }

  fnGetBalInfo(baloon){
    debugger;
    this.setState({
      baloonInfo:baloon
    })
  }
}

export default Board;
