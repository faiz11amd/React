import "./Board.css";
import React from "react";
import Baloon from '../Baloon/index';
import Arrow from  '../Arrow/index';
function template() {
  return (
    <div className="board">
       <Arrow baloonInfo={this.state.baloonInfo}  fnClearBalInfo={this.fnClearBalInfo} />
       <Baloon fnGetBalInfo={this.fnGetBalInfo} l="250px" t="50px" s="40px"/>
       <Baloon fnGetBalInfo={this.fnGetBalInfo} l="150px" t="100px" s="70px"/>
       <Baloon fnGetBalInfo={this.fnGetBalInfo} l="250px" t="200px" s="100px"/>
       <Baloon fnGetBalInfo={this.fnGetBalInfo} l="150px" t="300px" s="40px"/>
    </div>
  );
};

export default template;
