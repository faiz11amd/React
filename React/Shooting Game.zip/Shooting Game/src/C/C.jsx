import "./C.css";
import React from "react";
import {ctx} from '../context'

function template() {
  return (
    <div className="c">
      <h1>C :</h1>
      <ctx.Consumer>
           {
              (data)=>{
               return <div>{data}</div> 
              }
           }
      </ctx.Consumer>
    </div>
  );
};

export default template;
