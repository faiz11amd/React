import "./A.css";
import React from "react";
import B from '../B/index';
function template() {
  return (
    <div className="a">
      <B />
    </div>
  );
};

export default template;
