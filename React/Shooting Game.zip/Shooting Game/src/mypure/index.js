import mypure from "./mypure";
export default mypure;
