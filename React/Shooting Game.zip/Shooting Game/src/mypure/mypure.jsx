import "./mypure.css";
import React from "react";

function template() {
  return (
    <div className="mypure">
      <h1>mypure</h1>
      <h1>{this.props.n}</h1>
    </div>
  );
};

export default template;
