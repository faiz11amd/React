import React    from "react";
import template from "./mypure.jsx";

class mypure extends React.PureComponent {


  render() {
    console.log('mypure render');
    return template.call(this);
  }
}


export default mypure;
