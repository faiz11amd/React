import "./Baloon.css";
import React from "react";

function template() {
  return (
    <div onClick={this.fnBalClick.bind(this)} className="baloon" style={{left:this.props.l,top:this.props.t,height:this.props.s,width:this.props.s}}>
    </div>
  );
};

export default template;
