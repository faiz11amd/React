import React    from "react";
import template from "./Baloon.jsx";

class Baloon extends React.Component {
  render() {
    return template.call(this);
  }

  fnBalClick(e){
    this.props.fnGetBalInfo(e.target);
    var activeBal=document.querySelector('.baloon-active');
    if(activeBal){
      activeBal.classList.remove('baloon-active');
    }
    e.target.classList.add('baloon-active')
  }
}

export default Baloon;
