import "./TableCom.css";
import React from "react";

function template() {
  return (
    <div className="table-com">
       <table border='1px'>
         <tbody>
          <tr>
             {
               this.props.h.map((v,i)=>{
                  return   <th key={'tcth'+i}>{v}</th>
               })
             }
          </tr>

          {
            this.props.d.map((o,i)=>{
                  return <tr key={'tctr'+i}>
                       {
                         this.props.k.map((myKey,i)=>{
                             return <td key={'tctd'+i}>{o[myKey]}</td>
                         })
                       }
                  </tr>
            })
          }
          </tbody>
       </table>
    </div>
  );
};

export default template;
