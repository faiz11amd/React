import "./B.css";
import React from "react";
import C from '../C/index';
function template() {
  return (
    <div className="b">
      <C />
    </div>
  );
};

export default template;
