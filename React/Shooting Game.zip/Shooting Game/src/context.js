import React    from "react";

export const ctx=React.createContext();