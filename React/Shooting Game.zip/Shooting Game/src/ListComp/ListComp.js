import React    from "react";
import template from "./ListComp.jsx";

class ListComp extends React.Component {
  render() {
    return template.call(this);
  }
}

export default ListComp;
