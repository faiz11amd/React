import "./ListComp.css";
import React from "react";

function template() {
  return (
    <div className="list-comp">
       <ul>
         {
           this.props.data.map((v,i)=>{
              return  <li key={'reuselist'+i}>{v}</li>
           })
         }
       </ul>
    </div>
  );
};

export default template;
