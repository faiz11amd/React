import ListComp from "./ListComp";
export default ListComp;
