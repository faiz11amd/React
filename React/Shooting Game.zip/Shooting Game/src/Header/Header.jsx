import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header">
        My first react App
    </div>
  );
};

export default template;
