import selectcomp from "./selectcomp";
export default selectcomp;
