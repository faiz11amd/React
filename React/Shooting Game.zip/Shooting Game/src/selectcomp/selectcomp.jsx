import "./selectcomp.css";
import React from "react";

function template() {
  return (
    <div className="selectcomp">
        <select>
           {
             this.props.d.map((v,i)=>{
                  return <option key={'resutselect'+i}>{v}</option>
             })
           }
        </select>
    </div>
  );
};

export default template;
