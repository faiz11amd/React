import React    from "react";
import template from "./selectcomp.jsx";

class selectcomp extends React.Component {
  render() {
    return template.call(this);
  }
}

export default selectcomp;
